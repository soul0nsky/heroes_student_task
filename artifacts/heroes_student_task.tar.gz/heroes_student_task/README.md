# Heroes Battle - Реализация алгоритмов

Проект реализации ключевых алгоритмов для пошаговой стратегической игры "Heroes Battle".

## 📋 Описание

Проект включает реализацию 4 алгоритмов, которые управляют поведением компьютерного противника:

| Класс | Назначение | Сложность |
|-------|-----------|-----------|
| `GeneratePresetImpl` | Генерация оптимальной армии компьютера | O(n × m) |
| `SimulateBattleImpl` | Симуляция пошагового боя | O(n² × log n) |
| `SuitableForAttackUnitsFinderImpl` | Поиск юнитов доступных для атаки | O(n × m) |
| `UnitTargetPathFinderImpl` | Поиск кратчайшего пути (A*) | O(W × H × log(W×H)) |

### ___Детальное описание и доказательство алгоритмов в папке `doc`___

## 🚀 Установка и запуск

### Требования
- Java 17+ (рекомендуется Java 21)
- Игра Heroes Battle (папка `heroes` с файлом `Heroes Battle-1.0.0.jar`)

### Подготовка проекта

Этот репозиторий содержит **только реализацию алгоритмов**. Для проверки задания вам нужны исходники игры.

**Структура проекта:**
```
heroes_project/                  # Корневая папка
├── heroes/                      # Игра (не в репозитории!)
│   ├── assets/
│   ├── jars/
│   └── Heroes Battle-1.0.0.jar
└── heroes_student_task/         # Этот репозиторий
    ├── src/programs/
    ├── libs/
    └── ...
```

**Инструкция:**

1. Создайте папку для проекта:
```bash
mkdir heroes_project
cd heroes_project
```

2. Клонируйте этот репозиторий:
```bash
git clone <URL_РЕПОЗИТОРИЯ> heroes_student_task
```

3. Добавьте папку `heroes` с игрой в корень `heroes_project/`
    - Скачайте игру с портала задания (архив `heroes.zip`)
    - Распакуйте её в `heroes_project/heroes/`

### Сборка JAR

```bash
cd heroes_student_task

# Компиляция
mkdir -p out
javac -cp "libs/heroes_task_lib-1.0-SNAPSHOT.jar" -d out src/programs/*.java

# Создание JAR
cd out
jar cf obf.jar programs/*.class

# Копирование в игру
cp obf.jar ../../heroes/jars/
```

### Запуск игры

```bash
cd ../..
cd heroes
java -jar "Heroes Battle-1.0.0.jar"
```
При возникновении сложностей используйте JDK v21
## 📁 Структура проекта

```
heroes_student_task/
├── src/
│   └── programs/
│       ├── GeneratePresetImpl.java      # Генерация армии
│       ├── SimulateBattleImpl.java      # Симуляция боя
│       ├── SuitableForAttackUnitsFinderImpl.java  # Поиск целей
│       └── UnitTargetPathFinderImpl.java # Поиск пути (A*)
├── libs/
│   └── heroes_task_lib-1.0-SNAPSHOT.jar # Библиотека игры
├── out/
│   ├── programs/*.class                  # Скомпилированные классы
│   └── obf.jar                          # Готовый артефакт
├── docs/
│   └── ДОКАЗАТЕЛЬСТВА_СЛОЖНОСТИ.md      # Обоснование алгоритмической сложности
└── README.md
```


## 🧪 Тестирование

1. Запустите игру
2. Нажмите "Начать новую игру"
3. Нажмите "Создать армию" → "Отладочный пресет"
4. Расставьте свою армию справа
5. Нажмите "Создать армию" → "Начать бой"

**Ожидаемый результат:**
- Армия компьютера создаётся (~1500 очков)
- Юниты перемещаются и атакуют
- Логи отображаются в консоли
- Бой завершается победой одной из сторон

## 📦 Артефакты

- `artifacts/obf.jar` — скомпилированная реализация
- `heroes_student_task.zip` — исходники для сдачи
- `heroes_student_task.tgz` — альтернативный архив

## 👤 Автор

Michael Solonskiy

## 📄 Лицензия

Учебный проект для дисциплины "Алгоритмы и структуры данных"